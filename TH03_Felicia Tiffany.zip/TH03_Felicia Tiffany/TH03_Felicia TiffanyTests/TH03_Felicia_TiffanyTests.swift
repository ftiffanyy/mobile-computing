//
//  TH03_Felicia_TiffanyTests.swift
//  TH03_Felicia TiffanyTests
//
//  Created by student on 01/10/25.
//

import Testing
@testable import TH03_Felicia_Tiffany

struct TH03_Felicia_TiffanyTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
