//
//  ContentView.swift
//  TH03_Felicia Tiffany
//
//  Created by student on 30/09/25.
//
import SwiftUI
struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem { Image(systemName: "house.fill")}
            Text("Activity")
                .tabItem { Image(systemName: "bolt.fill")}
            Text("Stats")
                .tabItem { Image(systemName: "chart.bar.fill")}
            Text("Settings")
                .tabItem { Image(systemName: "gearshape.fill")}
        }
    }
}
struct HomeView: View {
    @State private var textinput = ""
    var body: some View {
        NavigationStack {
                VStack(alignment: .leading, spacing: 20) {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Good Morning,")
                                .font(.title3)
                                .foregroundStyle(.secondary)
                            Text("Felicia Tiffany")
                                .font(.system(size: 34, weight: .heavy))
                        }
                        Spacer()
                        Image(systemName: "person.crop.circle.fill")
                            .resizable()
                            .frame(width: 52, height: 52)
                            .clipShape(Circle())
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    
                    TextField("Search", text: $textinput)
                    .padding(12)
                    .background(Color.white)
                    .cornerRadius(14)
                    .shadow(color: .black.opacity(0.4), radius: 4, y: 3)
                    .padding(.horizontal, 20)

                    GoalContainer()
                        .padding(.horizontal, 20)
         
                    VStack(spacing: 16) {
                        HStack(spacing: 16) {
                            StatCard(icon: "heart.fill", iconColor: .purple, value: "68 Bpm")
                            StatCard(icon: "flame.fill", iconColor: .orange, value: "0 Kcal")
                        }
                        HStack(spacing: 16) {
                            StatCard(icon: "scalemass.fill", iconColor: .green, value: "73 Kg")
                            StatCard(icon: "moon.zzz.fill", iconColor: .blue, value: "6.2 Hr")
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                }

            }
        }
    }

struct GoalContainer: View {
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(LinearGradient(colors: [.purple, .pink, .red],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                .shadow(radius: 8, y: 4)
            
            VStack(spacing: 20) {
                Text("Today's Goal")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.white)
                
                HStack(spacing: 16) {
                    GoalMiniCard(icon: "figure.walk", title: "4 Miles", subtitle: "@Thames Route")
                    GoalMiniCard(icon: "sailboat.fill", title: "2 Miles", subtitle: "@River Lea")
                }
                .frame(height: 140)
                .padding(.horizontal, 14)
            }
            .padding(.top, 14)
        }
        .frame(height: 240)
    }
}
struct GoalMiniCard: View {
    let icon: String
    let title: String
    let subtitle: String
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color.white.opacity(0.15))
                .overlay(
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .stroke(Color.white.opacity(0.25), lineWidth: 1)
                )
            VStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.white)
                Text(title)
                    .font(.headline)
                    .foregroundColor(.white)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.9))
            }
        }
    }
}

struct StatCard: View {
    let icon: String
    let iconColor: Color
    let value: String
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(Color.white)
                .shadow(color: .black.opacity(0.06), radius: 5, y: 3)
            
            VStack {
                HStack {
                    Image(systemName: icon)
                        .font(.system(size: 24))
                        .foregroundColor(iconColor)
                    Spacer()
                }
                Spacer()
                HStack {
                    Spacer()
                    Text(value)
                        .font(.headline)
                        .foregroundColor(.black)
                }
            }
            .padding(16)
        }
        .frame(height: 100)
        .shadow(color: .black.opacity(0.1), radius: 6, x:0, y:3)
    }
}
#Preview {
    ContentView()
}


