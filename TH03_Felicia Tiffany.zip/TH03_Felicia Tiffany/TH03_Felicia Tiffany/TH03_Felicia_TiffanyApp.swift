//
//  TH03_Felicia_TiffanyApp.swift
//  TH03_Felicia Tiffany
//
//  Created by student on 01/10/25.
//

import SwiftUI

@main
struct TH03_Felicia_TiffanyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
