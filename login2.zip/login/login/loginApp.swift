//
//  loginApp.swift
//  login
//
//  Created by student on 05/11/25.
//

import SwiftUI

@main
struct loginApp: App {
    var body: some Scene {
        WindowGroup {
            StartView()
        }
    }
}
