//
//  TH02_Felicia_TiffanyApp.swift
//  TH02_Felicia Tiffany
//
//  Created by student on 23/09/25.
//

import SwiftUI

@main
struct TH02_Felicia_TiffanyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
