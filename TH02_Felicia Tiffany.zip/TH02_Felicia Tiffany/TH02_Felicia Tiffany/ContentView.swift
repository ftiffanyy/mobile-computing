//
//  ContentView.swift
//  TH02_Felicia Tiffany
//
//  Created by student on 23/09/25.
//

import SwiftUI

struct Todo: Identifiable {
    let id = UUID()
    var title: String
    var date: Date
}

struct ContentView: View {
    @State private var todos: [Todo] = []
    @State private var judul: String = ""
    @State private var tanggal: Date = Date()
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("To Do List 📝")
                .font(.largeTitle).bold(true)
                .padding(.leading)
                .padding(.top, 8)
            
            List(todos) { todo in
                VStack(alignment: .leading) {
                    Text(todo.title)
                        .font(.headline)
                    Text(todo.date, style: .date)
                        .foregroundColor(.secondary)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
            }
            
            HStack {
                TextField("Judul", text: $judul)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                DatePicker("", selection: $tanggal, displayedComponents: .date).labelsHidden()
                
                Button(action: {
                    if !judul.isEmpty {
                        let todo = Todo(title: judul, date: tanggal)
                        todos.append(todo)
                        judul = ""
                            }
                        })
                        {
                            Image(systemName: "plus.circle.fill").font(.title)
                        }
                    }.padding(.horizontal)
                }
            }

        }
        
#Preview {
    ContentView()
}
