//
//  TH02_Felicia_TiffanyTests.swift
//  TH02_Felicia TiffanyTests
//
//  Created by student on 23/09/25.
//

import Testing
@testable import TH02_Felicia_Tiffany

struct TH02_Felicia_TiffanyTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
