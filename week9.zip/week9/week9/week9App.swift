//
//  week9App.swift
//  week9
//
//  Created by student on 06/11/25.
//

import SwiftUI

@main
struct week9App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
