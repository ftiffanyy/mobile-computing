//
//  week9Tests.swift
//  week9Tests
//
//  Created by student on 06/11/25.
//

import Testing
@testable import week9

struct week9Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
