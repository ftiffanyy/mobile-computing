//
//  week5App.swift
//  week5
//
//  Created by student on 09/10/25.
//

import SwiftUI

@main
struct week5App: App {
    var body: some Scene {
        WindowGroup {
            TaskListView()
        }
    }
}
