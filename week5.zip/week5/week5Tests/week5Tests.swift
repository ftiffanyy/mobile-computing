//
//  week5Tests.swift
//  week5Tests
//
//  Created by student on 09/10/25.
//

import Testing
@testable import week5

struct week5Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
