//
//  ContentView.swift
//  W01-Felicia
//
//  Created by student on 11/09/25.
//
// var = variabel yang bisa diubah valuenya
// let = konstanta (value gabisa berubah)

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Image("pooh")
            
            VStack {
                Image("felicia")
                    .resizable()
                    .scaledToFill()
                    .clipShape(Circle())
                    .frame(width: 200, height: 200)
                    .overlay(Circle().stroke(Color.orange, lineWidth:10))
                    .padding(20)
                Text("Hi, I'm \(name)")
                    .font(.system(size: 30))
                    .font(.headline)
                    .background(.yellow.opacity(0.8))
                    .padding(10)
                Text("My age is \(age)")
                    .font(.system(size: 25))
                    .background(.yellow.opacity(0.5))
                    .padding(10)
                Text("\(emoji)")
                    .font(.system(size: 70))
                    .background(.yellow.opacity(0.65)).cornerRadius(30)
            }
        }
        .padding()
    }
    let name = "Felicia"
    var age = 20
    var emoji = "🧸🍪🍜"
    
}
#Preview {
    ContentView()
}

