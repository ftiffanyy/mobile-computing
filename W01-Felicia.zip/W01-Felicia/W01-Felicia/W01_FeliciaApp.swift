//
//  W01_FeliciaApp.swift
//  W01-Felicia
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_FeliciaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
