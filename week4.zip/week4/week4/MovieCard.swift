//
//  MovieCard.swift
//  week4
//
//  Created by student on 02/10/25.
//

import SwiftUI


struct MovieCard: View {
    let movie: Movie

    var body: some View {
        ZStack(alignment: .bottomLeading) {
                    AsyncImage(url: URL(string: movie.posterURL)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                    } placeholder: {
                        Color.gray.opacity(0.3)
                    }
                    .frame(height: 250)
                    .cornerRadius(15)
                    .clipped()

                    LinearGradient(gradient: Gradient(colors: [.black.opacity(0.7), .clear]),
                                   startPoint: .bottom,
                                   endPoint: .top)
                        .cornerRadius(15)

                    VStack(alignment: .leading) {
                        Text(movie.title)
                            .font(.headline)
                            .foregroundColor(.white)
                        Text(movie.genre)
                            .font(.subheadline)
                            .foregroundColor(.white.opacity(0.7))
                    }
                    .padding()
                }
                .shadow(radius: 5)
            }
    }

