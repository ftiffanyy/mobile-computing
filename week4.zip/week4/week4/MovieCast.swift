//
//  MovieCast.swift
//  week4
//
//  Created by student on 02/10/25.
//
import SwiftUI

struct MovieCast: View {
    let movie: Movie

    // Grid layout 2 kolom
    let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {

            // Judul Film
            Text(movie.title)
                .font(.title)
                .bold()
                .padding(.horizontal)

            // Daftar Cast dalam grid 2 kolom
            ScrollView {
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(movie.cast) { member in
                        ZStack(alignment: .bottomLeading) {
                            // Foto
                            AsyncImage(url: URL(string: member.photoURL)) { image in
                                image
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                            } placeholder: {
                                Color.gray.opacity(0.3)
                            }
                            .frame(height: 200)
                            .clipShape(RoundedRectangle(cornerRadius: 15))
                            .clipped()

                            // Gradient overlay
                            LinearGradient(
                                gradient: Gradient(colors: [.black.opacity(0.7), .clear]),
                                startPoint: .bottom,
                                endPoint: .top
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 15))
                            .frame(height: 200)

                            // Nama aktor
                            Text(member.name)
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding(8)
                        }
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .stroke(Color.white.opacity(0.4), lineWidth: 1)
                                .background(
                                    RoundedRectangle(cornerRadius: 15)
                                        .fill(Color.black.opacity(0.15))
                                )
                        )
                        .shadow(color: Color.black.opacity(0.3), radius: 6, x: 0, y: 4)
                    }
                }
                .padding(.horizontal)
            }
        }
        .padding(.vertical)
    }
}
