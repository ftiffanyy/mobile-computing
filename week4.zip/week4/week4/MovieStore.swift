//
//  MovieStore.swift
//  week4
//
//  Created by student on 02/10/25.
//

import Foundation
import Combine

final class MovieStore: ObservableObject {
    @Published var movies: [Movie] = [
        Movie(title: "Lilo & Stitch", genre: "Family", year: "2025", posterURL: "https://image.tmdb.org/t/p/original/tUae3mefrDVTgm5mRzqWnZK6fOP.jpg", detail: "The wildly funny and touching story of a lonely Hawaiian girl and the fugitive alien who helps to mend her broken family.",
            cast: [
                CastMember(name: "Maia Kealoha", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/jqsKbBF28V2Oq5tKPR5USkNufwC.jpg"),
                CastMember(name: "Sydney Agudong", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/3K5hJ3meeClHWsPKetqd9qgyveJ.jpg"),
                CastMember(name: "Chris Sanders", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/6CtrIOCxggJ5eIAWeFQqd4Hs9FP.jpg"),
                CastMember(name: "Zach Galifianakis", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/qsDfoUlRnXHUiqZeBPWHzmgmKGX.jpg"),
                CastMember(name: "Billy Magnussen", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/ugyx7Wn2uAWsNlR5eX4yWFsGV2Y.jpg")
            ]),
        Movie(title: "How to Train Your Dragon", genre: "Family", year: "2025", posterURL: "https://image.tmdb.org/t/p/original/53dsJ3oEnBhTBVMigWJ9tkA5bzJ.jpg", detail : "On the rugged isle of Berk, where Vikings and dragons have been bitter enemies for generations, Hiccup stands apart, defying centuries of tradition when he befriends Toothless, a feared Night Fury dragon. Their unlikely bond reveals the true nature of dragons, challenging the very foundations of Viking society.",
              cast: [
                  CastMember(name: "Mason Thames", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/iTGIj516E2tHB44lmjAS6nNMNU1.jpg"),
                  CastMember(name: "Nico Parker", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/gt0NJClVSCPCEfcPgcLj3f85uLa.jpg"),
                  CastMember(name: "Gerard Butler", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/rTO5opVC3Gs6hPYAxWSP9eEjogi.jpg"),
                  CastMember(name: "Nick Frost", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/2CHS4t6miNGLgMQAjhFqb4fFuKS.jpg"),
                  CastMember(name: "Gabriel Howell", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/u3PTI9FlrpGFZVMoHXZZBiYWMCl.jpg"),
                  CastMember(name: "Julian Dennison", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/pP9tymIRkOEEQqetcC1Yby5rGbi.jpg")
              ]),
        Movie(title: "Mission: impossible - The Final Reckoning", genre: "Action", year: "2025", posterURL: "https://image.tmdb.org/t/p/original/iKPsC9EFUafRP9SrUznI61getVP.jpg", detail : "Ethan Hunt and team continue their search for the terrifying AI known as the Entity — which has infiltrated intelligence networks all over the globe — with the world's governments and a mysterious ghost from Hunt's past on their trail. Joined by new allies and armed with the means to shut the Entity down for good, Hunt is in a race against time to prevent the world as we know it from changing forever.",
              cast: [
                  CastMember(name: "Tom Cruise", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/maf8PhSvDCdEwjEMbYfGpojR5RP.jpg"),
                  CastMember(name: "Hayley Atwell", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/x57wXHexIjD2ywly9cRA4rov7cu.jpg"),
                  CastMember(name: "Ving Rhames", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/4gpLVNKPZlVucc4fT2fSZ7DksTK.jpg"),
                  CastMember(name: "Simon Pegg", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg"),
                  CastMember(name: "Rebecca Ferguson", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg"),
                  CastMember(name: "Esai Morales", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg")
              ]
),
        Movie(title: "Christopher Robin", genre: "Family", year: "2018", posterURL: "https://image.tmdb.org/t/p/original/2H8ehxbxSMHDUMGXB8DYXd1En1k.jpg", detail : "Christopher Robin, the boy who had countless adventures in the Hundred Acre Wood, has grown up and lost his way. Now it’s up to his spirited and loveable stuffed animals, Winnie The Pooh, Tigger, Piglet, and the rest of the gang, to rekindle their friendship and remind him of endless days of childlike wonder and make-believe, when doing nothing was the very best something.",
              cast: [
                      CastMember(name: "Ewan McGregor", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/q2UDxfwWnmXTB7khOUF3J9puBVP.jpg"),
                      CastMember(name: "Hayley Atwell", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/x57wXHexIjD2ywly9cRA4rov7cu.jpg"),
                      CastMember(name: "Bronte Carmichael", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/fwm0THujqVnPjGeZ1rJndUFZhcP.jpg"),
                      CastMember(name: "Mark Gatiss", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg"),
                      CastMember(name: "Jim Cummings", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg"),
                      CastMember(name: "Kaitlyn Maher", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg")
                  ]),
        Movie(title: "Zootopia", genre: "Family", year: "2016", posterURL: "https://image.tmdb.org/t/p/original/kyiEmCk6mOenJiL7s3LspVKkoZM.jpg", detail : "Determined to prove herself, Officer Judy Hopps, the first bunny on Zootopia's police force, jumps at the chance to crack her first case - even if it means partnering with scam-artist fox Nick Wilde to solve the mystery.",
              cast: [
                      CastMember(name: "Ginnifer Goodwin", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/jqsKbBF28V2Oq5tKPR5USkNufwC.jpg"),
                      CastMember(name: "Jason Bateman", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/x57wXHexIjD2ywly9cRA4rov7cu.jpg"),
                      CastMember(name: "Idris Elba", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg"),
                      CastMember(name: "Jenny Slate", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg"),
                      CastMember(name: "J.K. Simmons", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg")
                  ]),
        Movie(title: "Red Notice", genre: "Action", year: "2021", posterURL: "https://image.tmdb.org/t/p/original/wdE6ewaKZHr62bLqCn7A2DiGShm.jpg", detail : "An Interpol-issued Red Notice is a global alert to hunt and capture the world's most wanted. But when a daring heist brings together the FBI's top profiler and two rival criminals, there's no telling what will happen.",
              cast: [
                      CastMember(name: "Dwayne Johnson", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/5QApZVV8FUFlVxQpIK3Ew6cqotq.jpg"),
                      CastMember(name: "Ryan Reynolds", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/trzgptffGvAlAT6MEu01fz47cLW.jpg"),
                      CastMember(name: "Gal Gadot", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg"),
                      CastMember(name: "Ritu Arya", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg"),
                      CastMember(name: "Chris Diamantopoulos", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg"),
                      CastMember(name: "Julius Tennon", photoURL: "https://media.themoviedb.org/t/p/w600_and_h900_bestv2/g55dgcZQkLMolkKqgP7OD2yfGXu.jpg")
                  ])]
              
    @Published var searchText: String = ""
        
        var filteredMovies: [Movie] {
            if searchText.isEmpty {
                return movies
            } else {
                return movies.filter {
                    $0.title.localizedCaseInsensitiveContains(searchText)
                }
            }
        }
}
