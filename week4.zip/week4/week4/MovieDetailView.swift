//
//  MovieDetailView.swift
//  week4
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieDetailView: View {
    let movie: Movie
    
    var body: some View {
        TabView {
            MovieAbout(movie: movie)
                .tabItem {
                    Image(systemName: "movieclapper.fill")
                    Text("About")
                }
            
            MovieCast(movie: movie)
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Cast")
                }
        }
    }
}
