//
//  MovieAbout.swift
//  week4
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieAbout: View {
    let movie: Movie
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
            
                AsyncImage(url: URL(string: movie.posterURL)) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                } placeholder: {
                    ProgressView()
                }
                .frame(maxWidth: .infinity, maxHeight: 300)
                .cornerRadius(12)
                .shadow(radius: 5)

                Text(movie.title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.leading)
                
                Text("Year: \(movie.year)")
                    .font(.headline)
                    .foregroundColor(.secondary)

                Text("Genre: \(movie.genre)")
                    .font(.headline)
                    .foregroundColor(.secondary)

                // Detail / Synopsis
                Text("Synopsis")
                    .font(.title2)
                    .bold()
                    .padding(.top, 10)

                Text(movie.detail)
                    .font(.body)
                    .foregroundColor(.primary)
                    .fixedSize(horizontal: false, vertical: true)

                Spacer()
            }
            .padding()
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

