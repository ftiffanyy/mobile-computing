//
//  Movie.swift
//  week4
//
//  Created by student on 02/10/25.
//

import Foundation

struct Movie : Identifiable {
    let id = UUID()
    var title: String
    var genre: String
    var year: String
    var posterURL: String
    var detail: String
    var cast: [CastMember]
}
