//
//  ContentView.swift
//  week4
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var store = MovieStore()
    
    var body: some View {
        NavigationStack {
            VStack {
                TextField("Search Movies...", text: $store.searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)
                
                MovieGridView(store: store)
            }
            .navigationTitle("🎥 UCFlix")
        }
    }
}

#Preview {
    ContentView()
}

