//
//  week4App.swift
//  week4
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct week4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
