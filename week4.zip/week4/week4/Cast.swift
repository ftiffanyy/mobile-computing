//
//  Cast.swift
//  week4
//
//  Created by student on 02/10/25.
//

import Foundation

struct CastMember: Identifiable {
    let id = UUID()
    var name: String
    var photoURL: String
}

struct Cast {
    var groupCast: [CastMember]
}
