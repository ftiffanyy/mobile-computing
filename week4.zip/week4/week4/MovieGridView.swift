//
//  MovieGridView.swift
//  week4
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieGridView: View {
    @ObservedObject var store: MovieStore
        
    let columns = [GridItem(.flexible()), GridItem(.flexible())]
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 16) {
                ForEach(store.filteredMovies) { movie in
                    NavigationLink(destination: MovieDetailView(movie: movie)) {
                        MovieCard(movie: movie)
                    } 
                }
            }
            .padding()
        }
    }
}
